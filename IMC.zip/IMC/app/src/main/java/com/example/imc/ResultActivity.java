package com.example.imc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {
    TextView resultado;
    String cttNome;
    Float BBAltura, BBPeso, BBResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        resultado = (TextView) findViewById(R.id.textViewResult);

        Intent intent = getIntent();
        cttNome = intent.getStringExtra("nome");
        BBAltura = Float.parseFloat(intent.getStringExtra("altura"));
        BBPeso = Float.parseFloat(intent.getStringExtra("peso"));
        BBResult = BBPeso / (BBAltura * BBAltura);

        String strResult = "Olá " + cttNome + "!";
        strResult = strResult + "\n" + "IMC = " + BBResult.toString();

        if(BBResult < 17) {
            strResult = strResult + "\n" + "Muito abaixo do peso";
        }
        else if(BBResult < 18.49){
            strResult = strResult + "\n" + "Abaixo do peso";
        }
        else if(BBResult < 24.99){
            strResult = strResult + "\n" + "Peso normal";
        }
        else if(BBResult < 29.99){
            strResult = strResult + "\n" + "Acima do peso";
        }
        else if(BBResult < 34.99){
            strResult = strResult + "\n" + "Obesidade I";
        }
        else if(BBResult < 39.99){
            strResult = strResult + "\n" + "Obesidade II (severa)";
        }
        else {
            strResult = strResult + "\n" + "Obesidade III (mórbida)";
        }

        resultado.setText(strResult);
    }
}